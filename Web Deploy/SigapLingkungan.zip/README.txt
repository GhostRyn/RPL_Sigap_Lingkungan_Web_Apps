SIGAP LINGKUNGAN - PANDUAN DEPLOY INFINITYFREE
1. Panel InfinityFree > MySQL Databases > buat database (catat Hostname, DB Name, Username).
1b. (Opsional) Import schema.sql lewat phpMyAdmin untuk membuat tabel dengan foreign key dan indeks; install.php tetap dijalankan untuk akun contoh.
2. Edit config.php: DB_HOST, DB_NAME, DB_USER, DB_PASS, APP_KEY (teks acak panjang, jangan diubah lagi), INSTALL_TOKEN.
3. Upload SEMUA isi folder ini ke folder htdocs (File Manager / FTP), termasuk folder storage dan file .htaccess.
4. Buka https://domainanda/install.php?token=ISI_TOKEN_ANDA  -> tabel & akun contoh dibuat.
5. HAPUS install.php dari htdocs. Ganti/hapus akun contoh (lihat layar install).
6. Buka https://domainanda/ -> login atau Daftar (OTP tampil di layar selama DEMO_OTP=true).
Catatan: InfinityFree tidak menyediakan SMS; untuk produksi sambungkan gateway SMS di api.php (aksi daftar & ubah).
